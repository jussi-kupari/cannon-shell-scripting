#!/bin/bash
# This file does NOT contain carriage returns.
echo "Hello world."
