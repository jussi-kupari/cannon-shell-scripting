#!/bin/bash
HOST_NAME=$(hostname)
echo "This script is running on ${HOST_NAME}."
